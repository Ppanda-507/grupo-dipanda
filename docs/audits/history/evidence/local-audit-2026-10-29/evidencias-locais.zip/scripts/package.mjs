import { mkdir, mkdtemp, cp, stat, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import os from 'node:os';
import { pages, renderPage } from '../src/pages.mjs';
import { assertProjectAssets } from './project-assets.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
// A fresh directory prevents stale files/secrets from an older delivery surviving.
const destination = path.join(await mkdtemp(path.join(os.tmpdir(), 'dipanda-delivery-')), 'dipanda');
await assertProjectAssets(path.join(root, 'public'), Object.keys(pages).map(renderPage));
await mkdir(destination, { recursive: true });
for (const item of ['src', 'public', 'scripts', 'api', 'deploy', 'reports', 'tests', 'package.json', 'package-lock.json', 'vercel.json', '.vercelignore', '.gitignore', '.env.example', 'README.md']) await cp(path.join(root, item), path.join(destination, item), { recursive: true });
const build = path.join(root, 'dist');
if ((await stat(build).catch(() => null))?.isDirectory()) await cp(build, path.join(destination, 'dist'), { recursive: true });
const assets = await readdir(path.join(destination, 'public/assets/figma'));
for (const asset of assets.filter(file => /\.(svg|png|jpg|jpeg|webp|avif)$/i.test(file))) if ((await stat(path.join(destination, 'public/assets/figma', asset))).size < 2) throw new Error(`Empty asset: ${asset}`);
const checks = path.join(os.tmpdir(), 'dipanda-browser-checks', 'results.json');
if ((await stat(checks).catch(() => null))?.isFile()) await cp(checks, path.join(destination, 'tests', 'browser-results.json'));
const motionChecks = path.join(os.tmpdir(), 'dipanda-browser-checks', 'motion-results.json');
if ((await stat(motionChecks).catch(() => null))?.isFile()) await cp(motionChecks, path.join(destination, 'tests', 'motion-results.json'));
const heroChecks = path.join(os.tmpdir(), 'dipanda-browser-checks', 'hero-results.json');
if ((await stat(heroChecks).catch(() => null))?.isFile()) await cp(heroChecks, path.join(destination, 'tests', 'hero-results.json'));
const processChecks = path.join(os.tmpdir(), 'dipanda-browser-checks', 'process-results.json');
if ((await stat(processChecks).catch(() => null))?.isFile()) await cp(processChecks, path.join(destination, 'tests', 'process-results.json'));
for (const report of ['people-problem-images-results.json', 'editorial-problem-images-results.json', 'solution-cover-gallery-results.json', 'adapted-problem-images-results.json', 'image-quality-results.json', 'manual-report-image-results.json', 'problem-responsive-results.json', 'values-marquee-results.json', 'image-reference-results.json', 'compact-solution-results.json', 'about-problem-results.json', 'hero-shader-results.json', 'hero-startup-results.json', 'hero-performance-before.json', 'hero-performance-after.json', 'about-highlight-results.json']) {
  const reportPath = path.join(os.tmpdir(), 'dipanda-browser-checks', report);
  if ((await stat(reportPath).catch(() => null))?.isFile()) await cp(reportPath, path.join(destination, 'tests', report));
}
await writeFile(path.join(destination, 'DELIVERY.txt'), 'Projeto completo Dipanda. Consulte README.md para executar e configurar. Imagens e fontes locais incluídas.\n');
console.log(destination);
