import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { codeVersion } from './audit-code-version.mjs';

// The parent only orchestrates files. AUDIT_NODE selects the runtime executing tests.
const runtime = process.env.AUDIT_NODE || process.execPath;
const directory = 'reports/local-audit-2026-10-29';
await fs.mkdir(directory, { recursive: true });
const version = await codeVersion();
await fs.writeFile(path.join(directory, 'code-version.json'), JSON.stringify(version, null, 2));
const engines = (process.env.AUDIT_ENGINES || 'chromium,firefox,webkit').split(',');
const targets = (process.env.AUDIT_TARGETS || 'http://127.0.0.1:4173,https://127.0.0.1:4443').split(',');
const runs = [];
if (process.env.AUDIT_DIAGNOSTICS === '1') {
  const child = spawn(runtime, ['scripts/diagnose-browser-profile.mjs'], { env: { ...process.env, BROWSER_ENGINE: 'chromium', PROFILE_DEBUG: '1', DEBUG: 'pw:browser' }, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.on('data', data => { stdout += data; }); child.stderr.on('data', data => { stderr += data; });
  const exit = await new Promise(resolve => child.on('exit', resolve));
  await fs.writeFile(path.join(directory, 'profile-diagnostic-unrestricted.json'), stdout);
  await fs.writeFile(path.join(directory, 'profile-diagnostic-unrestricted.txt'), stderr);
  if (exit !== 0) throw new Error('Dedicated profile diagnostic failed.');
}
for (const origin of targets) for (const engine of engines) {
  const label = `${engine}-${new URL(origin).protocol.slice(0, -1)}`;
  const temporary = path.join(os.tmpdir(), `dipanda-${label}-${Date.now()}.json`);
  let log = '';
  console.log(`Starting ${label}`);
  const startedAt = new Date().toISOString();
  const child = spawn(runtime, ['scripts/check-consent-storage.mjs'], {
    env: { ...process.env, BROWSER_ENGINE: engine, TEST_URL: origin, DIPANDA_CONSENT_REPORT: temporary }, windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', data => { log += data; process.stdout.write(data); });
  child.stderr.on('data', data => { log += data; process.stderr.write(data); });
  const timeout = setTimeout(() => child.kill(), 300000);
  const exit = await new Promise(resolve => { child.on('error', error => { log += error.stack; resolve(null); }); child.on('exit', resolve); });
  clearTimeout(timeout);
  let result;
  try { result = JSON.parse(await fs.readFile(temporary, 'utf8')); await fs.writeFile(path.join(directory, label + '.json'), JSON.stringify(result, null, 2)); }
  catch { result = { status: 'INCONCLUSIVE', reason: 'Browser launch/run did not produce a report; see captured log.' }; }
  await fs.writeFile(path.join(directory, label + '.txt'), log);
  runs.push({ label, origin, engine, startedAt, finishedAt: new Date().toISOString(), exit, summary: result.summary, status: result.status, snapshot: version.snapshot });
  await fs.writeFile(path.join(directory, 'runs.json'), JSON.stringify(runs, null, 2));
}
const after = await codeVersion();
if (after.snapshot !== version.snapshot) throw new Error('Code changed during the run; regenerate results.');
console.log(JSON.stringify(runs, null, 2));
